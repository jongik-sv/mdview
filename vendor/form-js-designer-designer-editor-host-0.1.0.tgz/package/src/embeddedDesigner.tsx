import { h, render } from 'preact';
import { useLayoutEffect, useRef, useState } from 'preact/hooks';
// @ts-ignore — form-js-editor has no bundled type declarations
import { FormEditor } from '@bpmn-io/form-js-editor';
import { DesignerContainerModule, readStoredPanelMode } from '@form-js-designer/designer-core';
import { DesignerComponentsModule, migrateLegacyTabsSchema } from '@form-js-designer/designer-components';
import type { PanelMode } from './components/PropsPanelModeToggle';
import { LayoutHeightModule } from '@form-js-designer/designer-runtime';
import { PaletteModule } from './modules/PaletteModule';
import { OutlineModule } from './modules/OutlineModule';
import { MarqueeModule } from './modules/MarqueeModule';
import { InlineLabelEditModule } from './modules/InlineLabelEditModule';
import { ShortcutModule } from './modules/ShortcutModule';
import { PropsPanelModule } from './modules/PropsPanelModule';
import { PropsPanelService } from './modules/PropsPanelService';
import { LivePreviewModule } from './modules/LivePreviewModule';
import { ValidateModule } from './modules/ValidateModule';
import { ExportModule } from './modules/ExportModule';
import { ComponentResizeOverlay } from './components/ComponentResizeOverlay';
import { PropsPanelContainer } from './components/PropsPanelContainer';
import { LeftRailTabs, type LeftRailTab } from './components/LeftRailTabs';
import { installPropsPanelFocusGuard } from './hooks/usePropsPanelFocusGuard';

type EventBusLike = {
  on: (event: string, handler: (...args: unknown[]) => void) => void;
  off: (event: string, handler: (...args: unknown[]) => void) => void;
};

// Layout CSS — replicates host App.tsx imports so form-js editor + outline +
// properties panel render correctly inside the modal. Without these the
// palette stretches horizontally, outline doesn't render, props panel is
// offscreen, and the 3-column layout collapses.
import '@bpmn-io/form-js-viewer/dist/assets/form-js.css';
import '@bpmn-io/form-js-editor/dist/assets/form-js-editor-base.css';
import '@bpmn-io/form-js-editor/dist/assets/form-js-editor.css';
import '@bpmn-io/form-js-editor/dist/assets/properties-panel.css';
import '@bpmn-io/form-js-editor/dist/assets/dragula.css';
import './app.css';
// 캔버스 spacing override — app.css 다음 순서여야 cascade 우선
import '@form-js-designer/designer-components/canvas-spacing.css';

export type FormSchema = { type: string; components: unknown[]; [k: string]: unknown };

export interface MountEmbeddedEditorModalOptions {
  /** 모달 wrapper가 마운트될 부모. 기본 document.body */
  container?: HTMLElement;
  /** 디자이너 초기 스키마 */
  initialSchema: FormSchema;
  /**
   * FU-C: 첫 마운트 시 사용할 패널 모드. 지정하면 sessionStorage 보다 우선한다.
   * 미지정 시 `readStoredPanelMode()`(sessionStorage) 로 폴백.
   */
  initialPanelMode?: PanelMode;
  /** 자동저장 콜백. close 시 항상 호출. async OK. 실패(reject/throw) 시 모달 유지 */
  onSave: (schema: FormSchema) => void | Promise<void>;
  /** 모달 unmount 직후 호출. triggerClose / destroy 양쪽 경로 모두에서 fire (정확히 1회) */
  onClose?: () => void;
}

export interface EmbeddedEditorHandle {
  /** 외부 강제 종료 — onSave 호출 없이 즉시 cleanup. onClose는 fire */
  destroy(): void;
  /**
   * 현재 schema 조회 (sync).
   *
   * 주의 — 라이브 편집 중간값은 반영되지 않는다. 반환값은
   * `initialSchema` (모달 오픈 시점) 또는 `triggerClose`가
   * `editor.saveSchema()`로 갱신한 마지막 저장 스키마이다. 편집 중인
   * 라이브 스키마가 필요하면 `editor.saveSchema()`를 외부에서 직접 호출.
   */
  getSchema(): FormSchema;
}

interface FormEditorInstance {
  importSchema: (schema: FormSchema) => Promise<void>;
  // form-js editor.saveSchema() returns the schema object directly,
  // not wrapped in { schema }. (See customEditor.ts and e2e/tabs-tabpanel.spec.ts.)
  saveSchema: () => Promise<FormSchema>;
  destroy: () => void;
  get?: (key: string, optional?: boolean) => unknown;
}

const ROOT_CLASS = 'fjd-embedded-designer-root';
const HEADER_CLASS = 'fjd-embedded-designer-header';
const CONTENT_CLASS = 'fjd-embedded-designer-content';
const ACTIONS_CLASS = 'fjd-embedded-designer-actions';
const SAVE_BTN_CLASS = 'fjd-embedded-designer-save';
const CLOSE_BTN_CLASS = 'fjd-embedded-designer-close';
const CANVAS_CLASS = 'fjd-embedded-designer-canvas';
const LAYOUT_CLASS = 'fjd-embedded-designer-layout';
const AREA_CLASS = 'fjd-embedded-designer-area';
const MAIN_CLASS = 'fjd-embedded-designer-main';
const PROPS_CLASS = 'fjd-embedded-designer-props';
const PROPS_NATIVE_CLASS = 'fjd-embedded-designer-props-native';

/**
 * Imperative mount of the form-js editor inside a fullscreen modal shell.
 *
 * The modal shell is a vanilla DOM wrapper (header + content); the designer
 * canvas is a Preact <App /> mounted inside the content area. ESC and the
 * [닫기] button both funnel into triggerClose, which awaits onSave then
 * cleans up. handle.destroy() is for external force-close (e.g. tiptap
 * editor.destroy()) and skips onSave but still fires onClose.
 *
 * The inner layout replicates host App.tsx — Outline (left) + form-js canvas
 * (center) + form-js native properties panel (right) — but intentionally
 * omits Sidebar tabs / Live Preview / Validate / Export toolbar (the
 * embedded version is simpler than the standalone host).
 */
export async function mountEmbeddedEditorModal(
  opts: MountEmbeddedEditorModalOptions,
): Promise<EmbeddedEditorHandle> {
  const { container = document.body, initialSchema, initialPanelMode, onSave, onClose } = opts;

  // 1. Build modal shell
  const wrapper = document.createElement('div');
  wrapper.className = ROOT_CLASS;
  wrapper.tabIndex = -1;
  const header = document.createElement('div');
  header.className = HEADER_CLASS;
  const title = document.createElement('h2');
  title.textContent = 'Form Designer';
  const actions = document.createElement('div');
  actions.className = ACTIONS_CLASS;
  const saveBtn = document.createElement('button');
  saveBtn.type = 'button';
  saveBtn.className = SAVE_BTN_CLASS;
  saveBtn.textContent = '저장';
  const closeBtn = document.createElement('button');
  closeBtn.type = 'button';
  closeBtn.className = CLOSE_BTN_CLASS;
  closeBtn.textContent = '닫기';
  actions.append(saveBtn, closeBtn);
  header.append(title, actions);
  const content = document.createElement('div');
  content.className = CONTENT_CLASS;
  wrapper.append(header, content);
  container.appendChild(wrapper);

  // 2. Lock body scroll
  const prevBodyOverflow = document.body.style.overflow;
  document.body.style.overflow = 'hidden';

  // 3. Mount Preact app + form-js editor
  let editorInstance: FormEditorInstance | null = null;
  let attachedPropsPanel: { detach?: () => void } | null = null;
  let currentSchema: FormSchema = initialSchema;
  let closing = false;

  const App = () => {
    const editorRef = useRef<HTMLDivElement>(null);
    const outlineRef = useRef<HTMLDivElement>(null);
    const paletteSlotRef = useRef<HTMLDivElement>(null);
    const propsRef = useRef<HTMLDivElement>(null);
    // TSK-12-02: ref to expose editorInstance into JSX for ComponentResizeOverlay.
    // editorInstance (outer closure let) is assigned before setServices() triggers
    // re-render, so copying it into a ref here keeps the value stable across renders
    // without creating a second source of truth.
    const editorInstanceRef = useRef<FormEditorInstance | null>(null);
    // designer-components 전용 props 서비스 — importSchema 완료 후 setState로
    // 채워서 PropsPanelContainer 가 selection.changed 를 수신하도록 한다.
    const [services, setServices] = useState<{
      propsPanel: PropsPanelService | null;
      eventBus: EventBusLike | null;
    }>({ propsPanel: null, eventBus: null });
    const [leftTab, setLeftTab] = useState<LeftRailTab>('components');
    // FU-C: initialPanelMode (caller-supplied) takes precedence over sessionStorage.
    // web App.tsx reads sessionStorage directly and manages its own state; embedded
    // modal (tiptap) passes 'simple' explicitly so the first render is already correct.
    // The setter is intentionally unused: the embedded modal does not expose a
    // toggle — the mode is fixed for the lifetime of this modal instance.
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const [panelMode, _setPanelMode] = useState<PanelMode>(
      initialPanelMode ?? readStoredPanelMode(),
    );

    useLayoutEffect(() => {
      const editorEl = editorRef.current;
      if (!editorEl) return;
      const additionalModules: unknown[] = [
        DesignerContainerModule,
        DesignerComponentsModule,
        PaletteModule,
        OutlineModule,
        MarqueeModule,
        InlineLabelEditModule,
        ShortcutModule,
        PropsPanelModule,
        LivePreviewModule,
        ValidateModule,
        ExportModule,
        LayoutHeightModule,
      ];
      // form-js 의 propertiesPanel.parent 를 offscreen 으로 만들어두면
      // 내부의 fjs-editor-properties-container 가 detached 상태로 생성된다.
      // 이후 propertiesPanel.attachTo() 로 우측 .props-panel-native 슬롯에 마운트한다.
      const offscreenPropsParent = document.createElement('div');
      try {
        const editor = new FormEditor({
          container: editorEl,
          additionalModules,
          propertiesPanel: { parent: offscreenPropsParent },
        } as ConstructorParameters<typeof FormEditor>[0]) as unknown as FormEditorInstance;
        editorInstance = editor;
        editorInstanceRef.current = editor;
        editor
          .importSchema(migrateLegacyTabsSchema(initialSchema))
          .then(() => {
            // wire outline + props panel after schema imports — same as App.tsx
            const outlineEl = outlineRef.current;
            if (outlineEl && typeof editor.get === 'function') {
              try {
                const outlinePanel = editor.get('outlinePanel', false) as
                  | { mount?: (el: HTMLElement) => void }
                  | undefined;
                outlinePanel?.mount?.(outlineEl);
              } catch { /* ignore */ }
            }
            // 팔레트 DOM을 left-rail components 슬롯으로 옮긴다.
            // form-js dragula는 element 자체에 listener를 박으므로 reparent 안전.
            const paletteEl = editorEl.querySelector('.fjs-palette-container');
            const paletteSlot = paletteSlotRef.current;
            if (paletteEl && paletteSlot && paletteEl.parentElement !== paletteSlot) {
              paletteSlot.appendChild(paletteEl);
            }
            const propsEl = propsRef.current;
            if (propsEl && typeof editor.get === 'function') {
              try {
                const propsPanel = editor.get('propertiesPanel', false) as
                  | { attachTo?: (el: HTMLElement) => void; detach?: () => void }
                  | undefined;
                if (propsPanel?.attachTo) {
                  propsPanel.attachTo(propsEl);
                  attachedPropsPanel = propsPanel;
                }
              } catch { /* ignore */ }
            }
            // DI 서비스 획득 — designer-components 전용 props 패널 (host App.tsx 와 동일)
            if (typeof editor.get === 'function') {
              try {
                const propsPanelSvc = editor.get('propsPanel', false) as
                  | PropsPanelService
                  | undefined;
                const eventBus = editor.get('eventBus', false) as EventBusLike | undefined;
                // FU-C: push the initial panel mode into the service so the
                // native panel filter provider already sees 'simple' on the
                // first selection.changed reflow — before any React effect runs.
                propsPanelSvc?.setMode(panelMode);
                setServices({
                  propsPanel: propsPanelSvc ?? null,
                  eventBus: eventBus ?? null,
                });
              } catch (err) {
                console.warn('[embedded-designer] DI 서비스 획득 실패:', err);
              }
            }
          })
          .catch((err: Error) => {
            console.error('[embedded-designer] importSchema failed:', err);
          });
      } catch (err) {
        console.error('[embedded-designer] FormEditor construction failed:', err);
      }
      return () => {
        // detach propertiesPanel before destroy to avoid stale-DOM warnings
        try { attachedPropsPanel?.detach?.(); } catch { /* ignore */ }
        attachedPropsPanel = null;
        try { editorInstance?.destroy(); } catch { /* ignore */ }
        editorInstance = null;
        editorInstanceRef.current = null;
      };
    }, []);

    return h(
      'div',
      { class: `${LAYOUT_CLASS} app-layout` },
      h(
        'div',
        { class: `${AREA_CLASS} editor-area` },
        h(
          'div',
          { class: `${MAIN_CLASS} editor-main` },
          h(
            'div',
            { class: 'left-rail', 'data-active-panel': leftTab },
            h(LeftRailTabs, { activeTab: leftTab, onTabChange: setLeftTab }),
            h(
              'div',
              { class: 'left-rail__panels' },
              h('div', {
                id: 'left-rail-panel-components',
                class: 'left-rail__panel',
                'data-panel': 'components',
                role: 'tabpanel',
                'aria-labelledby': 'left-tab-components',
                ref: paletteSlotRef,
              }),
              h('div', {
                id: 'left-rail-panel-outline',
                class: 'left-rail__panel',
                'data-panel': 'outline',
                'data-outline-container': '',
                role: 'tabpanel',
                'aria-labelledby': 'left-tab-outline',
                ref: outlineRef,
              }),
            ),
          ),
          h('div', { class: `${CANVAS_CLASS} editor-container`, ref: editorRef }),
          // TSK-12-02: ComponentResizeOverlay — mirrors App.tsx line 322-324.
          // services.eventBus 를 조건으로 사용: setServices() 트리거 시점에
          // editorInstanceRef.current 도 반드시 채워져 있음이 보장된다.
          services.eventBus && editorInstanceRef.current
            ? h(ComponentResizeOverlay, { editor: editorInstanceRef.current as { get(svc: string, required?: boolean): unknown } })
            : null,
        ),
      ),
      h(
        'div',
        { class: `${PROPS_CLASS} side-panel` },
        h(
          'div',
          { class: 'props-panel-stack' },
          h('div', { class: `${PROPS_NATIVE_CLASS} props-panel-native`, ref: propsRef }),
          // designer-components 전용 속성 (padding, orientation, ...) — host App.tsx 와 동일
          // FU-C: pass panelMode so PropsPanelContainer.getGroups() uses the
          // correct mode from the first selection.changed event.
          h(PropsPanelContainer, {
            propsPanelService: services.propsPanel,
            eventBus: services.eventBus,
            mode: panelMode,
          }),
        ),
      ),
    );
  };

  render(h(App, {}), content);

  // 4. Install focus guard scoped to this modal.
  //    NOTE: installPropsPanelFocusGuard mutates HTMLElement.prototype.focus.
  //    Stacking two concurrent modals would corrupt the patch chain because
  //    each call captures the current prototype as `orig` and restores to it.
  //    Concurrent instances are intentionally prevented at the consumer side
  //    (designer-tiptap modalPortal enforces single-instance) — do not lift
  //    that constraint without first making the focus-guard install a
  //    refcount-aware operation.
  const uninstallFocusGuard = installPropsPanelFocusGuard(wrapper);

  // 5. Schema accessor — returns last-known schema (sync)
  //    triggerClose path awaits saveSchema before onSave for accurate snapshot
  const getSchema = (): FormSchema => currentSchema;

  // 6. finishClose — common cleanup, called by both triggerClose and destroy
  const finishClose = () => {
    if (closing) return;
    closing = true;
    render(null, content); // unmount Preact (also runs editor cleanup)
    wrapper.removeEventListener('keydown', keyHandler, true);
    closeBtn.removeEventListener('click', closeBtnHandler);
    saveBtn.removeEventListener('click', saveBtnHandler);
    uninstallFocusGuard();
    wrapper.remove();
    document.body.style.overflow = prevBodyOverflow;
    onClose?.();
  };

  // 6a. saveOnly — persist current schema via onSave, keep modal open.
  //     Reentry-guarded to prevent double-click races; saveBtn is disabled
  //     during the in-flight save and re-enabled on completion.
  let saving = false;
  const saveOnly = async () => {
    if (closing || saving) return;
    if (!editorInstance || typeof editorInstance.saveSchema !== 'function') return;
    saving = true;
    saveBtn.disabled = true;
    try {
      const saved = await editorInstance.saveSchema();
      const schemaToSave: FormSchema = saved ?? currentSchema;
      currentSchema = schemaToSave;
      await onSave(schemaToSave);
    } catch (err) {
      console.error('[embedded-designer] onSave failed:', err);
    } finally {
      saving = false;
      saveBtn.disabled = false;
    }
  };

  // 7. triggerClose — auto-save then cleanup
  const triggerClose = async () => {
    if (closing) return;
    try {
      let schemaToSave: FormSchema = currentSchema;
      if (editorInstance && typeof editorInstance.saveSchema === 'function') {
        const saved = await editorInstance.saveSchema();
        schemaToSave = saved ?? currentSchema;
        currentSchema = schemaToSave;
      }
      await onSave(schemaToSave);
    } catch (err) {
      console.error('[embedded-designer] onSave failed:', err);
      return; // keep modal open
    }
    finishClose();
  };

  // 8. Listeners
  const keyHandler = (e: KeyboardEvent) => {
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      void triggerClose();
    }
  };
  const closeBtnHandler = () => {
    void triggerClose();
  };
  const saveBtnHandler = () => {
    void saveOnly();
  };
  wrapper.addEventListener('keydown', keyHandler, true);
  closeBtn.addEventListener('click', closeBtnHandler);
  saveBtn.addEventListener('click', saveBtnHandler);

  // 9. Focus the wrapper so ESC works immediately
  wrapper.focus();

  return {
    destroy() {
      finishClose();
    },
    getSchema,
  };
}
